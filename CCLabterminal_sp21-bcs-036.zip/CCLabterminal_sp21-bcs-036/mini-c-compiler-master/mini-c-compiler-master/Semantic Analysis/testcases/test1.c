#include<stdio.h>
void main()
{
    int n,i;
    int x;
    for (i=0;i<n;i++){
        if(i<10){
            int x;
            while(x<10){
                int x;
                x++;
            }
        }

    }

    x=3;
    
}
