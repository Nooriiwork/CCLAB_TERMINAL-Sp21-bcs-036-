#include<stdio.h>

struct student
{
  int rollNum;
  int marks;
};

int main()
{
 int a = 1, b=0;
 struct student student1;
 student1.rollNum = 1;
 student1.marks = 90;

 if(a >= 1 && a <= 10)
   	b++;

 else
       {  b--;
        /* }
}
