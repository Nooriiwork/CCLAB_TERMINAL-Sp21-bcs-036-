#include<stdio.h>
#define NUM 5

int main()
{
char A[] = "#define MAX 10";
char B[ ] = "Hello";
char ch  = 'B';
unsigned int a = 1;
printf("String = %s Value of Pi = %f", 3.14);

 	return 0;
}
