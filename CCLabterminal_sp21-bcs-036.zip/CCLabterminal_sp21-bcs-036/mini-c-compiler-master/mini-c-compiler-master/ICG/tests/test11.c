#include<stdio.h>
int square(int a, int b)
{
	int b = 2;
	return b;
}

int main()
{
	int num = 2;
	int num2;
	square(num,num);
	
	//printf("Square of %d is %d", num, square2(5));

	return 0;
}